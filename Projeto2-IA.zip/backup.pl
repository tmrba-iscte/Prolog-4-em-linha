%next_player(Player1, Player2) - permite saber qual � o pr�ximo jogador
next_player(1,2).
next_player(2,1).

%play_game/0
% Este predicado come�a por criar um tabuleiro com a dimensao 6x6 e
% validar a jogada do computador (player 1).
play_game():-
    initial_board(6, 6, B0),
    play(1,B0).

%play/1
%O predicado play tem como argumentos o jogador que deve jogar e o tabuleiro sobre o qual deve fazer a sua jogada.
% Este predicado e' recursivo de modo a permitir a alternancia das
% jogadas. A sua implementa�ao e constituida pela jogada do computador
% (play(1,B)) , pela jogada do jogador (play(2,B)) e pela verifica�ao
% do fim do jogo.
play(_,B0):-
    game_over(B0,T),
    calculate_board_value(T,Value),
    print_board(B0),
    write('Game Over!'),
    nl,
    display(Value),
    !.

play(1,B0):-
    write('Player:'),nl,
    print_board(B0),
    alphabeta(B0,6,-100,100,B1,_,1),
    !,
    play(2,B1).

play(2,B0):-
    write('Computer:'),nl,
    print_board(B0),
    write('Where to play? (C,L)'),
    read(C),
    read(L),
    valid_move(C,L,B0),
    add_move(2,C,L,B0,B1),
    !,
    play(1,B1).

%alphabeta/7
%minimax-alpha-beta
% O predicado que implementa o minimax e' chamado alfabeta e tem como
% argumentos o tabuleiro, o valor de profundidade que ainda e' permitido
% explorar, o alfa, o beta, o tabuleiro resultado, o score da avalia�ao
% do resultado na o'tica do computador e o jogador que se esta' a
% avaliar (minimizar ou a maximizar).
alphabeta(Bi, 0, _, _, Bi, Value, P):-
    calculate_board_heuristic(P,Bi,Value),
    !.

alphabeta(Bi, _, _, _, Bi, Value, _):-
    game_over(Bi,T),
    calculate_board_value(T,Value),
    !.


alphabeta(Bi, D, Alfa, Beta, Bf, Value, Player):-
    next_player(Player,Other),
    possible_moves(Player,Bi,L),
    !,
    evaluate_child(Other, L, D, Alfa, Beta, Bf, Value).

%evaluate_child/7
evaluate_child(Player, [B], D, Alfa, Beta, B, Value):-
    D1 is D-1,
    !,
    alphabeta(B, D1, Alfa, Beta, _, Value, Player).


evaluate_child(2, [Bi|T], D, Alfa, Beta,Bf, Value):-
    D1 is D-1,
    alphabeta(Bi, D1, Alfa, Beta, _, Value1, 2),
    !,
    evaluate_next_child_max(Value1,Bi, T, D, Alfa, Beta, Value, Bf).

evaluate_child(1, [Bi|T], D, Alfa, Beta,Bf, Value):-
    D1 is D-1,
    alphabeta(Bi, D1, Alfa, Beta, _, Value1, 1),
    !,
    evaluate_next_child_min(Value1,Bi, T, D, Alfa, Beta, Value, Bf).

%evaluate_next_child_max/8
evaluate_next_child_max(Value1,Bi, T, D, Alfa, Beta, Value, Bf):-
    Value1 < Beta,
    max(Value1,Alfa,NewAlfa),
    !,
    evaluate_child(2, T, D, NewAlfa, Beta, B2, Value2),
    max_board(Value1,Bi,Value2,B2,Value,Bf).

evaluate_next_child_max(Value1,Bi, _, _, _, _, Value1, Bi):- !.

%evaluate_next_child_min/8
evaluate_next_child_min(Value1,Bi, T, D, Alfa, Beta, Value, Bf):-
     Value1 > Alfa,
     min(Value1,Beta,NewBeta),
     !,
     evaluate_child(1, T, D, Alfa, NewBeta, B2, Value2),
     min_board(Value1,Bi,Value2,B2,Value,Bf).

evaluate_next_child_min(Value1,Bi, _, _, _, _, Value1, Bi):- !.


%possible_moves/3
possible_moves(X,B,L):-
    bagof(BP,generate_move(X,B,BP),L).

%max_board/6
max_board(Value1,B1,Value2,_,Value1,B1):-
    Value1 >= Value2.

max_board(Value1,_,Value2,B2,Value2,B2):-
    Value1 < Value2.

%min_board/6
min_board(Value1,B1,Value2,_,Value1,B1):-
    Value1 =< Value2.

min_board(Value1,_,Value2,B2,Value2,B2):-
    Value1 > Value2.

%max/3
max(X,Y,X):-
    X>=Y,!.
max(X,Y,Y):-
    Y>X.
%min/3
min(X,Y,X):-
    X=<Y,!.
min(X,Y,Y):-
    Y<X.

buildList(X, N, List):-
    findall(X, between(1, N, _), List).

replace(_,_,[],[]).

replace(X,Y,[X|T],[Y|T1]):-
    replace(X,Y,T,T1).

replace(X,Y,[Z|T],[Z|T1]):-
Z\=X,
    replace(X,Y,T,T1).

%(A)
initial_board(NumRows, _, Board):-
    buildList(0,NumRows,Aux),
    replace(_,Aux,Aux,Board).

%(B)
print_board(Board):-
    printAux(Board),
    write('--------------'),
    nl.

printAux([]).
printAux([Row|Rows]):-
  atomic_list_concat(Row, TRow),
  write(TRow),
  nl,
  printAux(Rows).


%(C)
valid_move(X,Y,Board):-
    %O elemento X da lista Board
    nth0(X,Board,Aux),
    indexOf(Aux,0,Y).

indexOf([Element|_], Element, 0).
indexOf([_|Tail], Element, Index):-
  indexOf(Tail, Element, Index1),
  Index is Index1+1.
%---------------------------------------------------------------
%(D)
add_move(Player,X,Y,InitialBoard,FinalBoard):-
    valid_move(X,Y,InitialBoard),
    append(Aux,[H|Tail],InitialBoard),
    length(Aux,X),
    append(Aux2,[_|T],H),
    length(Aux2,Y),
    append(Aux2,[Player|T],Aux3),
    append(Aux,[Aux3|Tail],FinalBoard).

add_move2(Player,X,Y,InitialBoard,FinalBoard):-
    valid_move(X,Y,InitialBoard),
    nth0(X,InitialBoard,L),
    replaceTeste(Y,L,Player,X2),
    replaceTeste(Y,InitialBoard,X2,FinalBoard).

%----------------------------------------------------------------
%(E)
generate_move(Player,InitialBoard,FinalBoard):-
    flatten(InitialBoard,Aux),
    sizeMatrix(InitialBoard,_,Y),
    indexOf(Aux,0,H),
    replaceTeste(H,Aux,Player,Aux2),
    list_to_matrix(Aux2,Y,FinalBoard).

list_to_matrix([], _, []).
list_to_matrix(List, Size, [Row|Matrix]):-
  list_to_matrix_row(List, Size, Row, Tail),
  list_to_matrix(Tail, Size, Matrix).

list_to_matrix_row(Tail, 0, [], Tail).
list_to_matrix_row([Item|List], Size, [Item|Row], Tail):-
  NSize is Size-1,
  list_to_matrix_row(List, NSize, Row, Tail).

replaceTeste(I, L, E, K) :-
  nth0(I, L, _, R),
  nth0(I, K, E, R).

length_of(N, Ls) :-
   length(Ls, N).

sizeMatrix(Mss, R, C) :-
   length(Mss, R),
   maplist(length_of(C), Mss).

%---------------------------------------------------------------
%(F)

game_over(Board,Winner):-
    horizontal1(Board),
    Winner = 1.

game_over(Board,Winner):-
    horizontal2(Board),
    Winner = 2.

game_over(Board,Winner):-
    vertical1(Board),
    Winner = 1.

game_over(Board,Winner):-
    vertical2(Board),
    Winner = 2.

game_over(Board,Winner):-
    diagonal(W,Board),
    Winner = W.

game_over(Board,Winner):-
    empate(Board),
    Winner = 0.

side_by_side4(X,Y,Z,W,[X,Y,Z,W|_]).
side_by_side4(X,Y,Z,W,[_|K]):-
    side_by_side4(X,Y,Z,W,K).


horizontal1(Board):-
    nth0(_,Board,X),
    side_by_side4(1,1,1,1,X).

horizontal2(Board):-
    nth0(_,Board,X),
    side_by_side4(2,2,2,2,X).


vertical1(Board):-
    extract_column(Board,_,X),
    side_by_side4(1,1,1,1,X).

vertical2(Board):-
    extract_column(Board,_,X),
    side_by_side4(2,2,2,2,X).

empate(Board):-
    flatten(Board,Aux),
    \+ (ismember(0,Aux)).

ismember(X,[X|_]).
ismember(X,[_|T]):-
    ismember(X,T).


diagonal(X,T):- append(_,[C1,C2,C3,C4|_],T),
		   append(I1,[X|_],C1),
		   append(I2,[X|_],C2),
		   append(I3,[X|_],C3),
		   append(I4,[X|_],C4),
		   length(I1,M1), length(I2,M2), length(I3,M3), length(I4,M4),
		   M2 is M1+1, M3 is M2+1, M4 is M3+1.

diagonal(X,T):- append(_,[C1,C2,C3,C4|_],T),
		   append(I1,[X|_],C1),
		   append(I2,[X|_],C2),
		   append(I3,[X|_],C3),
		   append(I4,[X|_],C4),
		   length(I1,M1), length(I2,M2), length(I3,M3), length(I4,M4),
		   M2 is M1-1, M3 is M2-1, M4 is M3-1.

extract_column([], _, []).
extract_column([X|Xs], I, [Y|Ys]) :-
    nth0(I, X, Y),
    extract_column(Xs, I, Ys).

%------------------------------------------------------
%(G)

calculate_board_value(Winner,Score):-
    Winner = 1 ->
    Score = 1.

calculate_board_value(Winner,Score):-
    Winner = 2 ->
    Score = -1.

calculate_board_value(Winner,Score):-
    Winner = 0 ->
    Score = 0.

%------------------------------------------------------------
%(H)

calculate_board_heuristic(Player,Board,Value):-
    Value = 0.




